#ifndef __BSP_THREAD_H__
#define __BSP_THREAD_H__


void get_hum_temp(float *ptemp, uint16_t *phum);

void bsp_thread_init(void);

#endif
