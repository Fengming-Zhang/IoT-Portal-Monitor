#ifndef __USER_MIAN_H__
#define __USER_MIAN_H__

#include "bsp_thread.h"

void user_main(void);
void app_thread_init(void);


#endif
